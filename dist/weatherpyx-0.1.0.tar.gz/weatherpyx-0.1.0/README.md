# WeatherPyx

Un wrapper elegante y sencillo para la API de OpenWeatherMap.

## Instalación

```bash
pip install weatherpyx